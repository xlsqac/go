// Package tests contains tests for GopherJS.
package tests
