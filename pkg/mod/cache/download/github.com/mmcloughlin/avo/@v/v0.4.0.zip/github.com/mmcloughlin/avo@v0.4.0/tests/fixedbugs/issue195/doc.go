// Package issue195 tests for correct argument size for a function without
// return types. This test is closely related to issue #191.
package issue195
