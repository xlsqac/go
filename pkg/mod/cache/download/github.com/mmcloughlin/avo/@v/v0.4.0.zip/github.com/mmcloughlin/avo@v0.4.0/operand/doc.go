// Package operand provides types for instruction operands.
package operand
