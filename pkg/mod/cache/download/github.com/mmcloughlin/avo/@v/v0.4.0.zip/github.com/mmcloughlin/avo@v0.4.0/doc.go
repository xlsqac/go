// Package avo is a high-level x86 assembly generator.
package avo
