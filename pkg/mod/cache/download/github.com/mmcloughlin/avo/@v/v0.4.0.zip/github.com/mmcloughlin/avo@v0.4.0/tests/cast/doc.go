// Package cast tests casting virtual registers to different sizes.
package cast
