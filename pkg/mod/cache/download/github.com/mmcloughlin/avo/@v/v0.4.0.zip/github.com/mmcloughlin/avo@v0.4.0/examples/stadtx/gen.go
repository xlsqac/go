package stadtx

//go:generate go run asm.go -out stadtx.s -stubs stub.go
