// Package add demonstrates an Add function in avo.
package add
