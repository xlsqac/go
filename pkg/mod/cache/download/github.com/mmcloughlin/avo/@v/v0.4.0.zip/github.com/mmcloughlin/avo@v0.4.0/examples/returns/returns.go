package returns

// Struct is used to demonstrate writing struct return values.
type Struct struct {
	Word  uint16
	Point [2]float64
	Quad  uint64
}
