// Package gp8 tests the register allocator by using as many 8-bit registers as possible.
package gp8
