# tests

System-level testing of `avo`.
