// Package tests contains avo integration tests.
package tests
