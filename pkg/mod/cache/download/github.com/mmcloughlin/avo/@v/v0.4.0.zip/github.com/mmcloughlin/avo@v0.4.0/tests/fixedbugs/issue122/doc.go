// Package issue122 tests consecutive labels.
package issue122
