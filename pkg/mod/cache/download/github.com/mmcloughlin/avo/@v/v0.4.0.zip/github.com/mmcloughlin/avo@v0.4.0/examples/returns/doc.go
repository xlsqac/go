// Package returns demonstrates how to write function return values in avo.
package returns
