// Package fnv1a implements FNV-1a in avo.
package fnv1a
