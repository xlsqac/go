// Package data shows how to define DATA sections in avo.
package data
