// Package upper32 tests liveness analysis of 32-bit operations on 64-bit registers.
package upper32
