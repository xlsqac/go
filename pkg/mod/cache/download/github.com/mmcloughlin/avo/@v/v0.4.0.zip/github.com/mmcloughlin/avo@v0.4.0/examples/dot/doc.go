// Package dot implements vector dot product in avo.
package dot
