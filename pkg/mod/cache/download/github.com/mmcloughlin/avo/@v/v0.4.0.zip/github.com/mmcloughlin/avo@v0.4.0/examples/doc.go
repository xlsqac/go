// Package examples provides examples of avo usage.
package examples
