// Package sha1 implements the SHA-1 hash in avo.
package sha1
