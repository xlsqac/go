// Package ext demonstrates how to interact with external types.
package ext

import "github.com/mmcloughlin/avo/examples/ext/ext"

// StructFieldB returns field B.
func StructFieldB(e ext.Struct) byte
