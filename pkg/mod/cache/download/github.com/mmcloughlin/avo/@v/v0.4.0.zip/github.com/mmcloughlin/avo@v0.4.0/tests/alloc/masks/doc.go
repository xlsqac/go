// Package masks tests that register liveness and allocation passes handle masks correctly.
package masks
