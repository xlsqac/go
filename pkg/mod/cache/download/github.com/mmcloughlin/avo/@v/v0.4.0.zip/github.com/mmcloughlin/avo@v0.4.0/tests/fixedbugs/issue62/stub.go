// Package issue62 tests for using Implement() with an unexported function.
package issue62

// private serves as an example unexported function to implement.
func private()
