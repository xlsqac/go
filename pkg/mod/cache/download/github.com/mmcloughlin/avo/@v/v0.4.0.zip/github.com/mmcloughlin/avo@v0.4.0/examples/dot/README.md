# dot

[Dot product](https://en.wikipedia.org/wiki/Dot_product) in `avo`. Ported from the [`dot_product.py` PeachPy example](https://github.com/Maratyszcza/PeachPy/blob/01d15157a973a4ae16b8046313ddab371ea582db/examples/go-generate/dot_product.py).
