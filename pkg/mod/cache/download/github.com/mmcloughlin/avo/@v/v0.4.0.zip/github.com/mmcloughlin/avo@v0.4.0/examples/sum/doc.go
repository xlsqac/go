// Package sum sums a slice in avo.
package sum
