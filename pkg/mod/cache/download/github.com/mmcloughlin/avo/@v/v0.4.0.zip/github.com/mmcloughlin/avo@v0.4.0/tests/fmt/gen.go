// Package fmt tests assembly printer formatting.
package fmt

//go:generate go run asm.go -out fmt.s -stubs stub.go
