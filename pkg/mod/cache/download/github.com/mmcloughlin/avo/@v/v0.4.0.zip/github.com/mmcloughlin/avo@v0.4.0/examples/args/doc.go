// Package args demonstrates how to load function arguments in avo.
package args
