// Package pragma demonstrates the use of compiler directives.
package pragma
