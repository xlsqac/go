// Package geohash implements integer geohash encoding in avo.
package geohash
