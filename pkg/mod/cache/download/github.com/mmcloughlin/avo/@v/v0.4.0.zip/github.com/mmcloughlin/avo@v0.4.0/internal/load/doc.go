// Package load loads the instruction database from external sources.
package load
