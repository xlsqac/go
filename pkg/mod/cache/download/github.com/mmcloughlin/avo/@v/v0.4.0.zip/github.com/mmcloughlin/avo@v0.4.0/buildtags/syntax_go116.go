//go:build !go1.17
// +build !go1.17

package buildtags

const (
	plusbuild = true
	gobuild   = false
)
